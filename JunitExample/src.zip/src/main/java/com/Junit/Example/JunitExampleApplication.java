package com.Junit.Example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JunitExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(JunitExampleApplication.class, args);
	}

}
