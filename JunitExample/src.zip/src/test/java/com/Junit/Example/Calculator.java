package com.Junit.Example;

public class Calculator {

	public int doSum(int a,int b,int c) {
		return a+b+c;
	}
	public int doProduct(int a,int b,int c)
	{
		return a*b*c;
	}
	public int doDivide(int a ,int b)
	{
		return a/b;
	}
}
